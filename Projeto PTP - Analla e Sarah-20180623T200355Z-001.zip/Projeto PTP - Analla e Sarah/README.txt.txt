﻿● O que foi feito (o básico e as funcionalidades extras implementadas) 
      O programa de editor de fotos tem as seguintes funcionalidades:
	  - Ler uma imagem em formato ppm;
	  - Realizar rotações;
	  - Fazer alterações no tamanho na imagem, tais como zoom e redução;
	  - Binarização, que deixa a imagem em tons de cinza;
	  - Aplicação de filtros, tais como: 
	      	  * Blurring;
		  * Sharpening;
		  * Detecção de bordas; 
		  * Filtro Laplaciano
		  * Filtro Gaussiano; 
		  * Filtro de Auto Relevo;
		  * Filtro de Edgess;
	 - Salvar a imagem editada no formato .ppm;

● O que não foi feito;
	Apesar de não ser um item obrigatório, mas vale salientar que tentamos fazer 	
	a interface gráfica do programa, mas não obtivemos êxito.

O programa pode ser compilado e executado diretamente no terminal utilizando os seguintes parâmetros:
gcc projeto.c -o projeto -g -w
./projeto
Ou também poderá ser compilado utilizando o programa Code Blocks executando diretamento por seu compilador;

O editor de fotos foi desenvolvido por:
Annalla Nayanne
Sarah Raquel

A contribuição de cada para o projeto está descrita abaixo: 
Sarah:Subrotinas de leitura, criação e salvamento da imagem e de binarização. 
Annalla: Subrotinas de filtros extras: gauss, laplace, auto relevo e edges. Zoom/Redução e rotacionamento.
O restante foi desenvolvido em conjunto e não há como fazer diferenciação.