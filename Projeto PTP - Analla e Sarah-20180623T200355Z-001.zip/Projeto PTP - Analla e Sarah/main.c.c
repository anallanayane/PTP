#include <stdio.h>
#include <stdlib.h>
#include "config.h"
//funcao principal;

int main(int argc, char* argv[])
{
    Imagem* img;

    int opcao = 1;       //declaracao da variavel opcao que o usuario ir� selecionar no menu;
    int opcao2;          //opcao que o usu�rio ir� selecionar no submenu.
	char nome[100];      //variavel que ir� guardar o nome do arquivo.
    int flag = 0;        //declaracao da vari�vel flag que v� se a imagem j� foi lida ou n�o. O valor padr�o � 0.

    //la�o criado para quando o usuario entrar no programa escolher uma imagem para ser editada antes de prosseguir;
    while (flag == 0){
            printf ("Seja Bem Vindo(a) ao nosso programa!\n\nPara prosseguir, selecione uma imagem para ser editada.\n");
        	printf("Nome do arquivo: ");
        	scanf("%s", nome);        //recebe a imagem;
        	img = ler_imagem(nome);   //leitura da imagem;
		    flag = 1;
        }
    //la�o de criacao do menu;
    while (opcao != 0 && flag == 1) {

        opcao = mostrar_menu();

        if (opcao == 1){    // opcao que o usuario pode fazer a leitura da imagem escolhida;
        	printf("Nome do arquivo: ");
        	scanf("%s", nome);         //recebe a imagem a ser editada;
        	img = ler_imagem(nome);   //ler a imagem;
        }
        else if(opcao == 2){
            img = binarizar(img);    // opcao para a foto ser binarizada;
        }
        else if(opcao == 3){        // opcao que o usuario poder� escolher dar o zoom 2x ou 4x;
			printf("Selecione: \n 1 - Zoom 2x \n 2 - Zoom4x");
			scanf("%i", &opcao2);
			if (opcao2 == 1){
				img = zoom2x(img);   //para zoom 2x;
			}
			else {
				img = zoom4x(img);  //para zoom 4x;
			}
	     }
	     else if(opcao == 4){      // opcao que o usuario podera escolher reduzir a imagem 2x ou 4x;
		printf("Selecione: \n 1 - Reduzir 2x \n 2- Reduzir 4x");
			scanf("%i", &opcao2);
			if (opcao2 == 1){
				img = reduzir2x(img);   //para reduzir 2x;
			}
			else {
				img = reduzir4x(img);   //para reduzir 4x;
			}
	      }
	    else if(opcao == 5){      // opcao que o usuario podera rotacionar a imagem em 3 angulos diferentes;
            printf("Selecione: \n 1 - 90 graus \n 2 - 180 graus 3 - 270 graus");
			scanf("%i", &opcao2);
			if (opcao2 == 1){
				img = rotacionar_90(img);     //para rotacionar 90�;
			}
			else if (opcao2 == 2){
				img = rotacionar_180(img);   //para rotacionar 180�;
			}
			else{
				img = rotacionar_270(img);	//para rotacionar 270�;
			}
	     }

        else if (opcao == 6){      // opcao para aplicar o filtro blur;
                 img = blur(img);
        }
        else if (opcao == 7){    // opcao para aplicar o filtro sharpen;
            img = sharpen(img);
    	}
    	else if (opcao == 8){   // opcao para aplicar o filtro deteccao de bordas;
            img = borda(img);
    	}
    	else if (opcao == 9){   // opcao para aplicar o filtro gaussiano;
            img = gauss(img);
    	}
    	else if (opcao == 10){   // opcao para aplicar o filtro laplaciano;
            img = laplace(img);
    	}
    	else if (opcao == 11){   // opcao para aplicar o filtro de auto relevo;
            img = relevo(img);
    	}
    	else if (opcao == 12){   // opcao para aplicar o filtro edges;
            img = edges(img);
    	}
        else if (opcao == 13){           //opcao para salvar o a imagem;
            printf("Nome do arquivo: ");
            scanf("%s", nome);          //recebe o nome da imagem a ser salva;
            salvar_imagem(img, nome);  //chamda da funcao salvar para salvar a imagem;
        }
        else if(opcao == 0){      //opcao para encerrar o programa;
            printf("O programa foi encerrado.");
        }
        else{      //caso seja escolhido uma opcao invalida;
                printf("Op��o inv�lida.");
        }
    }
    return 0;
}

