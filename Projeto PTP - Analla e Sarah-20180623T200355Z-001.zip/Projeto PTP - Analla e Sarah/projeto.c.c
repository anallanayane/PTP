#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "config.h"

//Cria��o da Imagem
Imagem* criar_imagem(int width, int height) {
    int i;
    Imagem* nova_img;    //declaracao do ponteiro nova_imagem do tipo Imagem;
    //Uso de aloca��o dinamica de mem�ria atrav�s da fun�ao malloc e do operador sizeof;
    nova_img = malloc(sizeof(Imagem));
    //Comando equivalente a fazer: (*nova_img).width = width, o mesmo serve para height; */
    nova_img->width = width;
    nova_img->height = height;

    nova_img->pixels = malloc(sizeof(Pixel*)* height);

    for (i = 0; i < nova_img->height; i++) {
        nova_img->pixels[i] = malloc(sizeof(Pixel) * width);
    }
    return nova_img;   //retorna a nova imagem;
}
//Leitura da Imagem
Imagem* ler_imagem(char* nome_arquivo) {
    char P3[3];          //verifica se a imagem � ascii ou binaria;
    int width, height;  //largura e altura da imagem em pixels;
    int max_value;     //valor maximo de tonalidade de cada pixel;
    int i, j, r, g, b;

    FILE* arquivo;   //nova variavel arquivo do tipo FILE;
    Imagem* img;

    // utiliza�ao do fopen para abrir o arquivo
    arquivo = fopen(nome_arquivo, "r");    //para ler o arquivo usa-se o modo read(r);

    fscanf(arquivo, "%s", P3);
    fscanf(arquivo, "%i %i %i",&width, &height, &max_value);

    img = criar_imagem(width, height);

    if (P3[1] == '3'){
        for (i = 0; i < height; i++) {
            for (j = 0; j < width; j++) {
                fscanf(arquivo, "%i %i %i", &r, &g, &b);
                img->pixels[i][j].r = r;
                img->pixels[i][j].g = g;
                img->pixels[i][j].b = b;
            }
        }
    }
    else if (P3[1] == '6'){
        fscanf(arquivo, "%c", &r);
        for (i = 0; i < height; i++) {
            for (j = 0; j < width; j++) {
                fscanf(arquivo, "%c%c%c", &r, &g, &b);
                img->pixels[i][j].r = (unsigned int) r;
                img->pixels[i][j].g = (unsigned int) g;
                img->pixels[i][j].b = (unsigned int) b;
          }
       }
    }
    else {
        printf("Error: Formato de imagem invalido!\n");    //caso o formato da imagem seja inv�lido a fun�ao retorna para NULL
        return NULL;
    }
    fclose(arquivo);   //fecha o arquivo;

    return img;
}
//Fun�ao para Salvar a Imagem criada;
void salvar_imagem(Imagem* img, char* nome_arquivo) {
    int i, j, r, g, b;
    FILE* arquivo;

    arquivo = fopen(nome_arquivo, "w");    //Para abrir um arquivo para escrita usa-SE a letra "w".
                                          //Esse modo automaticamente cria o arquivo, ou substitui seu conte�do anterior:

    fprintf(arquivo, "P3\n");
    fprintf(arquivo, "%i %i\n", img->width, img->height);
    fprintf(arquivo, "255\n");

    for (i = 0; i < img->height; i++) {
        for (j = 0; j < img->width; j++) {
            r = img->pixels[i][j].r;
            g = img->pixels[i][j].g;
            b = img->pixels[i][j].b;
            fprintf(arquivo, "%i %i %i\n", r, g, b);
        }
    }
    fclose(arquivo);
}
//calculo de satura�ao para a imagem;
int saturacao (int p) {
    if (p < 0) {
        return 0;
    } else if (p > 255) {
        return 255;
    } else {
        return p;
    }
}
//Recebe o ponteiro de imagem e retorna mod, que � a imagem modificada.
Imagem* binarizar(Imagem* org) {
    Imagem* mod = criar_imagem(org->width, org->height);
    int i, j, cinza = 0, p = 0;

    //la�o para varrer a imagem;
    for (i = 0; i < org->height; i++) {
        for (j = 0; j < org->width;j++) {
            cinza = 0;

            cinza = cinza + org->pixels[i][j].r;    //copia o valor de cinza para cada componente;
            cinza = cinza + org->pixels[i][j].g;
            cinza = cinza + org->pixels[i][j].b;

            cinza = saturacao(cinza/3);             //calculo da conversao para cinza;

            //verifica o valor para limiar 127;
            if(cinza > 127){
                p = 000;
            }else{
                p = 255;
            }

			//cada elemento da matriz recebe os valores de cinza;
            mod->pixels[i][j].r = cinza;
            mod->pixels[i][j].g = cinza;
            mod->pixels[i][j].b = cinza;
        }
    }
    //retorna a matriz modificada
    return mod;
}
//================================================== Transforma�oes com Imagens ============================================
//fun�ao limpar que � usada na funcao zoom para deixar a imagem tonalizada;
void limpar(Imagem* img, Pixel p) {
    int i, j;

    for (i = 0; i < img->height; i++) {
        for (j = 0; j < img->width; j++) {
            img->pixels[i][j] = p;
        }
    }
}
Pixel rgb(int r, int g, int b) {
    Pixel p;

    p.r = r;
    p.g = g;
    p.b = b;

    return p;
}

void igualar_imagem(Imagem* dst, Imagem* src) {
    int i, j;

    for (i = 0; i < src->height; i++) {
        for (j = 0; j < src->width; j++) {
            dst->pixels[i][j] = src->pixels[i][j];
        }
    }
}


//calculo da media do tipo Pixel;
Pixel calculo_media(Pixel a, Pixel b){
    Pixel tmp;

    tmp.r = (a.r + b.r) / 2;
    tmp.g = (a.g + b.g) / 2;
    tmp.b = (a.b + b.b) / 2;

    return tmp;
}
// calculo da media do tipo pixel para zoom 4x;
Pixel calculo_media4(Pixel* a, Pixel* b, Pixel* c, Pixel* d) {
    Pixel tmp;

    tmp.r = (a->r + b->r + c->r + d->r) / 4;
    tmp.g = (a->g + b->g + c->g + d->g) / 4;
    tmp.b = (a->b + b->b + c->b + d->b) / 4;

    return tmp;
}
//Funcao para dar zoom 2x na imagem;
Imagem* zoom2x(Imagem* org) {
    int i, j;
    Pixel p, a, b, d, e, c;
    Imagem* nova;

    nova = criar_imagem(org->width * 2, org->height * 2);
    limpar(nova, rgb(255, 255, 255));

    //la�o de aplica�ao do zoom 2x sobre cada pixel;
    for (i = 0; i < org->height; i++) {
        for (j = 0; j < org->width; j++) {
            nova->pixels[i*2][j*2] = org->pixels[i][j];
        }
    }

    for (i = 0; i < org->height; i++) {
        for (j = 0; j < org->width; j++) {
            if (j+1 < org->width) {
                a = org->pixels[i][j];
                b = org->pixels[i][j+1];
                p = calculo_media(a, b);
            }

            if (j != 0) {
                nova->pixels[i*2][j*2-1] = p;
            }

            if (i+1 < org->height) {
                a = org->pixels[i][j];
                b = org->pixels[i+1][j];
                p = calculo_media(a, b);
            }

            if (i != 0) {
                nova->pixels[i*2-1][j*2] = p;
            }
        }
    }

    for (i = 0; i < nova->height - 2; i += 2) {
        for (j = 0; j < nova->width - 2; j += 2) {
            a = nova->pixels[i][j+1];
            b = nova->pixels[i+1][j];
            d = nova->pixels[i+1][j+2];
            e = nova->pixels[i+2][j+1];
            c = calculo_media4(&a, &b, &d, &e);
            nova->pixels[i+1][j+1] = c;
        }
    }

    return nova;
}
//Fun�ao para dar zoom 4x;
Imagem* zoom4x(Imagem* org) {
    zoom2x(zoom2x(org));     //aplica a funcao zoom 2x por duas vezes, assim aumentando a imagem 4x;
}
//fun�ao para reduzir 2x a imagem;
Imagem* reduzir2x(Imagem* org) {
    int i, j;

    Pixel p, a, b, d, e, c;
    Imagem* nova;

    nova = criar_imagem(org->width / 2, org->height / 2);
    limpar(nova, rgb(255, 255, 255));

    //la�o para aplicar a redu�ao em cada pixel da imagem;
    for (i = 0; i < org->height - 2; i += 2) {
        for (j = 0; j < org->width - 2; j += 2) {
            a = org->pixels[i][j];
            b = org->pixels[i][j+1];
            c = org->pixels[i+1][j];
            d = org->pixels[i+1][j+1];
            p = calculo_media4(&a, &b, &c, &d);
            nova->pixels[i/2][j/2] = p;
        }
    }
    return nova;
}
//Fun�ao para reduzir 4x a imagem;
Imagem* reduzir4x(Imagem* org) {
    reduzir2x(reduzir2x(org));         //aplica a fun�ao reduzir 2x por duas vezes, assim reduzindo a imagem em 4x;
}
//Fun��o para criar a imagem rotacionada;
Imagem* rotacionar(Imagem* org) {
    int i, j;
    Imagem* tmp;

    tmp = criar_imagem(org->height, org->width);

    for (i = 0; i < org->height; i++) {
        for (j = 0; j < org->width; j++) {
            tmp->pixels[j][i].r = org->pixels[i][j].r;
            tmp->pixels[j][i].g = org->pixels[i][j].g;
            tmp->pixels[j][i].b = org->pixels[i][j].b;
        }
    }

    return tmp;
}
//codigo usado para rotacionar a imagem em 90 graus;
Imagem* rotacionar_90(Imagem* org) {
    Imagem* a;
    Imagem* b;
    Imagem* c;
    int i, j, ii, jj;

    a = rotacionar(org);
    b = criar_imagem(a->width, a->height);

    //la�o para rotacionar pixel a pixel em 90�;
    for (i = 0; i < a->height; ++i) {
        for (j = 0; j < a->width; ++j) {

            ii = a->height - i - 1;
            jj = a->width - j - 1;

            b->pixels[ii][jj].r = a->pixels[i][j].r;
            b->pixels[ii][jj].g = a->pixels[i][j].g;
            b->pixels[ii][jj].b = a->pixels[i][j].b;
        }
    }

    return b;
}
//Rotacionar a imagem em 180 graus;
Imagem* rotacionar_180(Imagem* org) {
    Imagem* b;
    int i, j, ii, jj;

    b = criar_imagem(org->width, org->height);

    for (i = 0; i < org->height; i++) {
        for (j = 0; j < org->width; j++) {

            ii = org->height - i - 1;
            jj = org->width - j - 1;

            b->pixels[ii][jj].r = org->pixels[i][j].r;
            b->pixels[ii][jj].g = org->pixels[i][j].g;
            b->pixels[ii][jj].b = org->pixels[i][j].b;
        }
    }
    return b;
}
//Rotacionar a imagem em  270 graus;
Imagem* rotacionar_270(Imagem* org) {
  rotacionar_90(rotacionar_90(rotacionar_90(org)));    //para rotacionar a imagem em 270� aplicamos a fun�ao rotacionar_90 tres vezes;
}
//------------------------------------------------ Aplica��o de Filtros -------------------------------------------------------
//Filtro Blurring
void calculo_blurring(Imagem* cop, Imagem* img, int i, int j) {
    int acr, acb, acg;
    int k, m, ii, jj;
    int produto;
    float filtro[3][3];

    //cria�ao da matriz 3x3 onde aplica-se os valores necessarios em cada casa para cria��o do filtro;
    filtro[0][0] = 1/9.0 * 1.0;
    filtro[0][1] = 1/9.0 * 1.0;
    filtro[0][2] = 1/9.0 * 1.0;

    filtro[1][0] = 1/9.0 * 1.0;
    filtro[1][1] = 1/9.0 * 1.0;
    filtro[1][2] = 1/9.0 * 1.0;

    filtro[2][0] = 1/9.0 * 1.0;
    filtro[2][1] = 1/9.0 * 1.0;
    filtro[2][2] = 1/9.0 * 1.0;

    acr = 0;
    acg = 0;
    acb = 0;

    k = i - 1;
    ii = 0;

    while (k <= i + 1) {
       m = j - 1;
       jj = 0;

       while (m <= j + 1) {
         acr += img->pixels[k][m].r * filtro[ii][jj];
         acg += img->pixels[k][m].g * filtro[ii][jj];
         acb += img->pixels[k][m].b * filtro[ii][jj];
         m++;
         jj++;
       }

       k++;
       ii++;
    }
    cop->pixels[i][j].r = saturacao(acr);
    cop->pixels[i][j].g = saturacao(acg);
    cop->pixels[i][j].b = saturacao(acb);
}
//Filtro Sharpenning
void calculo_sharpen(Imagem* cop, Imagem* img, int i, int j) {
    int acr, acb, acg;
    int k, m, ii, jj;
    int produto;
    float filtro[3][3];

    filtro[0][0] = 0;
    filtro[0][1] = -1;
    filtro[0][2] = 0;

    filtro[1][0] = -1;
    filtro[1][1] = 5;
    filtro[1][2] = -1;

    filtro[2][0] = 0;
    filtro[2][1] = -1;
    filtro[2][2] = 0;

    acr = 0;
    acg = 0;
    acb = 0;

    k = i - 1;
    ii = 0;

    while (k <= i + 1) {
       m = j - 1;
       jj = 0;

       while (m <= j + 1) {
         acr += img->pixels[k][m].r * filtro[ii][jj];
         acg += img->pixels[k][m].g * filtro[ii][jj];
         acb += img->pixels[k][m].b * filtro[ii][jj];
         ++m;
         ++jj;
       }

       k++;
       ii++;
    }
    cop->pixels[i][j].r = saturacao(acr);
    cop->pixels[i][j].g = saturacao(acg);
    cop->pixels[i][j].b = saturacao(acb);
}
//Filtro de detec�ao de borda;
void calculo_borda(Imagem* cop, Imagem* img, int i, int j) {
    int acr, acb, acg;
    int k, m ,ii, jj;
    int produto;
    float filtro[3][3];

    filtro[0][0] = -1;
    filtro[0][1] = -1;
    filtro[0][2] = -1;

    filtro[1][0] = -1;
    filtro[1][1] = 8;

    filtro[1][2] = -1;

    filtro[2][0] = -1;
    filtro[2][1] = -1;
    filtro[2][2] = -1;

    acr = 0;
    acg = 0;
    acb = 0;

    k = i - 1;
    ii = 0;

    while (k <= i + 1) {
       m = j - 1;
       jj = 0;

       while (m <= j + 1) {
         acr += img->pixels[k][m].r * filtro[ii][jj];
         acg += img->pixels[k][m].g * filtro[ii][jj];
         acb += img->pixels[k][m].b * filtro[ii][jj];
         ++m;
         ++jj;
       }

       k++;
       ii++;
    }
    cop->pixels[i][j].r = saturacao(acr);
    cop->pixels[i][j].g = saturacao(acg);
    cop->pixels[i][j].b = saturacao(acb);
}
//cria�ao da imagem com o filtro blurring aplicado;
Imagem* blur(Imagem* original) {
    Imagem* modificada = criar_imagem(original->width, original->height);
    int width, height;
    int i, j, k, m, r, g, b;
    int acc;

    height = original->height;
    width = original->width;

    for (i = 1; i < height - 1; i++) {
        for (j = 1; j < width - 1; j++) {
            calculo_blurring(modificada, original, i, j);
        }
    }
    return modificada;
}
//cria�ao da imagem com o filtro sharpen aplicado;
Imagem* sharpen(Imagem* original) {
    Imagem* modificada = criar_imagem(original->width, original->height);
    int width, height;
    int i, j, k, m, r, g, b;
    int acc;

    height = original->height;
    width = original->width;

    for (i = 1; i < height - 1; i++) {
        for (j = 1; j < width - 1; j++) {
            calculo_sharpen(modificada, original, i, j);
        }
    }
    return modificada;
}
//cria�ao da imagem com o filtro de detc��o de bordas aplicado;
Imagem* borda(Imagem* original) {
    Imagem* modificada = criar_imagem(original->width, original->height);
    int width, height;
    int i, j, k, m, r, g, b;
    int acc;

    height = original->height;
    width = original->width;

    for (i = 1; i < height - 1; i++) {
        for (j = 1; j < width - 1; j++) {
            calculo_borda(modificada, original, i, j);
        }
    }
    return modificada;
}
//====================================================== Extras ======================================================
//Filtro Gaussiano;
void calculo_gaussiano(Imagem* cop, Imagem* img, int i, int j) {
    int acr, acb, acg;
    int k, m, ii, jj;
    int produto;
    float filtro[3][3];

    filtro[0][0] = 1/16.0 * 1.0;
    filtro[0][1] = 1/16.0 * 2.0;
    filtro[0][2] = 1/16.0 * 2.0;

    filtro[1][0] = 1/16.0 * 2.0;
    filtro[1][1] = 1/16.0 * 4.0;
    filtro[1][2] = 1/16.0 * 2.0;

    filtro[2][0] = 1/16.0 * 2.0;
    filtro[2][1] = 1/16.0 * 2.0;
    filtro[2][2] = 1/16.0 * 1.0;

    acr = 0;
    acg = 0;
    acb = 0;

    k = i - 1;
    ii = 0;

    while (k <= i + 1) {
       m = j - 1;
       jj = 0;

       while (m <= j + 1) {
         acr += img->pixels[k][m].r * filtro[ii][jj];
         acg += img->pixels[k][m].g * filtro[ii][jj];
         acb += img->pixels[k][m].b * filtro[ii][jj];
         m++;
         jj++;
       }

       k++;
       ii++;
    }
    cop->pixels[i][j].r = saturacao(acr);
    cop->pixels[i][j].g = saturacao(acg);
    cop->pixels[i][j].b = saturacao(acb);
}
Imagem* gauss(Imagem* original) {
    Imagem* modificada = criar_imagem(original->width, original->height);
    int width, height;
    int i, j, k, m, r, g, b;
    int acc;

    height = original->height;
    width = original->width;

    for (i = 1; i < height - 1; i++) {
        for (j = 1; j < width - 1; j++) {
            calculo_gaussiano(modificada, original, i, j);
        }
    }
    return modificada;
}
//Filtro Laplaciano;
void calculo_laplace(Imagem* cop, Imagem* img, int i, int j) {
    int acr, acb, acg;
    int k, m, ii, jj;
    int produto;
    float filtro[3][3];


    filtro[0][0] = 0;
    filtro[0][1] = -1;
    filtro[0][2] = 0;

    filtro[1][0] = -1;
    filtro[1][1] = 4;
    filtro[1][2] = -1;

    filtro[2][0] = 0;
    filtro[2][1] = -1;
    filtro[2][2] = 0;

    acr = 0;
    acg = 0;
    acb = 0;

    k = i - 1;
    ii = 0;

    while (k <= i + 1) {
       m = j - 1;
       jj = 0;

       while (m <= j + 1) {
         acr += img->pixels[k][m].r * filtro[ii][jj];
         acg += img->pixels[k][m].g * filtro[ii][jj];
         acb += img->pixels[k][m].b * filtro[ii][jj];
         m++;
         jj++;
       }

       k++;
       ii++;
    }
    cop->pixels[i][j].r = saturacao(acr);
    cop->pixels[i][j].g = saturacao(acg);
    cop->pixels[i][j].b = saturacao(acb);
}
Imagem* laplace(Imagem* original) {
    Imagem* modificada = criar_imagem(original->width, original->height);
    int width, height;
    int i, j, k, m, r, g, b;
    int acc;

    height = original->height;
    width = original->width;

    for (i = 1; i < height - 1; i++) {
        for (j = 1; j < width - 1; j++) {
            calculo_laplace(modificada, original, i, j);
        }
    }
    return modificada;
}
//Filtro para auto relevo;
void calculo_relevo(Imagem* cop, Imagem* img, int i, int j) {
    int acr, acb, acg;
    int k, m, ii, jj;
    int produto;
    float filtro[3][3];

    filtro[0][0] = -2;
    filtro[0][1] = -1;
    filtro[0][2] = 0;

    filtro[1][0] = -1;
    filtro[1][1] = 1;
    filtro[1][2] = 1;

    filtro[2][0] = 0;
    filtro[2][1] = 1;
    filtro[2][2] = 2;

    acr = 0;
    acg = 0;
    acb = 0;

    k = i - 1;
    ii = 0;

    while (k <= i + 1) {
       m = j - 1;
       jj = 0;

       while (m <= j + 1) {
         acr += img->pixels[k][m].r * filtro[ii][jj];
         acg += img->pixels[k][m].g * filtro[ii][jj];
         acb += img->pixels[k][m].b * filtro[ii][jj];
         m++;
         jj++;
       }

       k++;
       ii++;
    }
    cop->pixels[i][j].r = saturacao(acr);
    cop->pixels[i][j].g = saturacao(acg);
    cop->pixels[i][j].b = saturacao(acb);
}
Imagem* relevo(Imagem* original) {
    Imagem* modificada = criar_imagem(original->width, original->height);
    int width, height;
    int i, j, k, m, r, g, b;
    int acc;

    height = original->height;
    width = original->width;

    for (i = 1; i < height - 1; i++) {
        for (j = 1; j < width - 1; j++) {
            calculo_relevo(modificada, original, i, j);
        }
    }
    return modificada;
}
//Filtro Edges;
void calculo_edges(Imagem* cop, Imagem* img, int i, int j) {
    int acr, acb, acg;
    int k, m, ii, jj;
    int produto;
    float filtro[5][5];

    filtro[0][0] = 0;
    filtro[0][1] = 0;
    filtro[0][2] = 0;
    filtro[0][3] = 0;
    filtro[0][4] = 0;

    filtro[1][0] = 0;
    filtro[1][1] = 0;
    filtro[1][2] = 0;
    filtro[1][3] = 0;
    filtro[1][4] = 0;

    filtro[2][0] = -1;
    filtro[2][1] = -1;
    filtro[2][2] = 2;
    filtro[2][3] = 0;
    filtro[2][4] = 0;

    filtro[3][0] = 0;
    filtro[3][1] = 0;
    filtro[3][2] = 0;
    filtro[3][3] = 0;
    filtro[3][4] = 0;

    filtro[4][0] = 0;
    filtro[4][1] = 0;
    filtro[4][2] = 0;
    filtro[4][3] = 0;
    filtro[4][4] = 0;

    acr = 0;
    acg = 0;
    acb = 0;

    k = i - 1;
    ii = 0;

    while (k <= i + 1) {
       m = j - 1;
       jj = 0;

       while (m <= j + 1) {
         acr += img->pixels[k][m].r * filtro[ii][jj];
         acg += img->pixels[k][m].g * filtro[ii][jj];
         acb += img->pixels[k][m].b * filtro[ii][jj];
         m++;
         jj++;
       }

       k++;
       ii++;
    }
    cop->pixels[i][j].r = saturacao(acr);
    cop->pixels[i][j].g = saturacao(acg);
    cop->pixels[i][j].b = saturacao(acb);
}
Imagem* edges(Imagem* original) {
    Imagem* modificada = criar_imagem(original->width, original->height);
    int width, height;
    int i, j, k, m, r, g, b;
    int acc;

    height = original->height;
    width = original->width;

    for (i = 1; i < height - 1; i++) {
        for (j = 1; j < width - 1; j++) {
            calculo_edges(modificada, original, i, j);
        }
    }
    return modificada;
}

//==================================================== Menu ====================================================================
//Menu do programa que ir� apresentar as op��es de edi��o da imagem.;
int mostrar_menu() {
    int opcao;

    printf("Selecione uma op��o: \n");

    printf("(1)  Ler uma nova imagem\n");
    printf("(2)  Binariza��o\n");
    printf("(3)  Zoom\n");
    printf("(4)  Reduzir\n");
    printf("(5)  Rotacionar\n");
    printf("(6)  Filtro Blur\n");
    printf("(7)  Filtro Sharpen\n");
    printf("(8)  Filtro Deteccao de Bordas\n");
    printf("(9)  Filtro Gaussiano\n");
    printf("(10) Filtro Laplaciano\n");
    printf("(11) Filtro de Auto Relevo\n");
    printf("(12) Filtro Edges\n");
    printf("(13) Salvar\n");
    printf("(0)  Sair\n\n");

    printf("Digite sua Opcao: ");
    scanf("%d", &opcao);

    return opcao;
}
