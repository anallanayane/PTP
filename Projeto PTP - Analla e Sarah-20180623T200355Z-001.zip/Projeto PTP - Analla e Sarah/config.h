#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

//declara��o do registro para o tipo de dados pixel com tres campos de armazenamento;
typedef struct Pixel {
    int r, g, b;
} Pixel;

//declara��o do registro para o tipo de dados Imagem com dois campos de armazenamento para largura e altura;
typedef struct Imagem {
    int width; //declara��o da variavel referente a largura da imagem em pixels;
    int height; //declara�ao da variavel referente a altura da imagem em pixels;
    Pixel** pixels;
} Imagem;

Imagem* criar_imagem(int width, int height); //funcao para criar a imagem;

Imagem* ler_imagem(char* nome_arquivo);     //funcao para ler a imagem;

void salvar_imagem(Imagem* img, char* nome_arquivo); //funcao para salvar a imagem apos as alteracoes;

int saturacao (int p);               //fun�ao para o calculo de saturacao da imagem;

Imagem* binarizar(Imagem* org);     //funcao para binarizar a imagem;

void limpar(Imagem* img, Pixel p);   //funcao para tonalizar em uma so cor a imagem;

void igualar_imagem(Imagem* dst, Imagem* src);

Imagem* zoom2x(Imagem* org);                //funcao para aumentar a imagem;
Imagem* zoom4x(Imagem* org);

Imagem* reduzir2x(Imagem* org);            //funcao para reducao da imagem;
Imagem* reduzir4x(Imagem* org);

Imagem* rotacionar(Imagem* org);          //funcoes para rotacao da imagem;
Imagem* rotacionar_90(Imagem* org);
Imagem* rotacionar_180(Imagem* org);
Imagem* rotacionar_270(Imagem* org);

void calculo_blurring(Imagem* cop, Imagem* img, int i, int j);        //funcao para o filtro blurring;
Imagem* blur(Imagem* original);

void calculo_sharpen(Imagem* cop, Imagem* img, int i, int j);        //funcao para o filtro de sharpen;
Imagem* sharpen(Imagem* original);

void calculo_borda(Imagem* cop, Imagem* img, int i, int j);         //funcao para o filtro de deteccao de bordas;
Imagem* borda(Imagem* original);

void calculo_gaussiano(Imagem* cop, Imagem* img, int i, int j);    //funcao para o filtro gaussiano;
Imagem* gauss(Imagem* original);

void calculo_laplace(Imagem* cop, Imagem* img, int i, int j);     //funcao para o filtro laplace;
Imagem* laplace(Imagem* original);

void calculo_relevo(Imagem* cop, Imagem* img, int i, int j);    //funcao para o filtro de auto relevo;
Imagem* relevo(Imagem* original);

void calculo_edges(Imagem* cop, Imagem* img, int i, int j);    //funcao para o filtro edges;
Imagem* edges(Imagem* original);

int mostrar_menu();   //fun�ao para exibir o menu do programa;


#endif // CONFIG_H_INCLUDED
